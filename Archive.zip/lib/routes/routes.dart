// import 'package:flutter/cupertino.dart';
// import 'package:mehfilista/features/auth/views/login_screen.dart';
// import 'package:mehfilista/features/onboarding/views/onboarding_screen.dart';
// // import 'package:mehfilista/components/navbar.dart';
// // import 'package:mehfilista/features/auth/views/login_screen.dart';
// // import 'package:mehfilista/features/auth/views/password_sent_screen.dart';
// // import 'package:mehfilista/features/auth/views/reset_pass_screen.dart';
// // import 'package:mehfilista/features/education/education_detail_screen.dart';
// // import 'package:mehfilista/features/onboard/view/onboard_screen.dart';
// // import 'package:mehfilista/features/profile/edit_profile.dart';
// // import 'package:mehfilista/features/rehabDetails/rehab_inner_exercise_detail_screen.dart';
// // import 'package:mehfilista/features/rehabDetails/rehab_plans_detail_screen.dart';
// // import 'package:mehfilista/features/workoutDetails/view/workout_detail_page.dart';
// import 'package:mehfilista/routes/routes_name.dart';

// class CustomRouter {
//   static Route<dynamic> allRoutes(RouteSettings settings) {
//     // final argument = settings.arguments;
//     switch (settings.name) {
//       // case home_screen_route:
//       //   return CupertinoPageRoute(builder: (_) => const HomeScreen());
//       case onboard_screen_route:
//         return CupertinoPageRoute(builder: (_) => OnboardingScreen());
//       case login_screen_route:
//         return CupertinoPageRoute(builder: (_) => LoginScreen());

//       default:
//         return CupertinoPageRoute(builder: (_) => const Text("Page Not Found"));
//     }
//   }
// }
