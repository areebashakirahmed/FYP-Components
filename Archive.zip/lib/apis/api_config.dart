class ApiConfig {
  static const String BaseUrl = "https://example.com/api";
}
