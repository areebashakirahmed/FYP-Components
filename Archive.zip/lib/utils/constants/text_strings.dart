/// This class contains all the App Text in String formats.
class TTexts {
  // -- GLOBAL Texts
  static const String and = "and";
}
