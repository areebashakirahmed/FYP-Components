package com.example.mehfilista

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
