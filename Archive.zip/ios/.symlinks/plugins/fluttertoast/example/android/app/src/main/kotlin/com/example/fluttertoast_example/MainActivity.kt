package com.example.fluttertoast_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
